<template>
  <div class="list">
    <div v-for="item in 100" :key="item">process组件</div>
  </div>
</template>

<script>
export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: "process",
};
</script>

<style lang="scss" scoped>
</style>